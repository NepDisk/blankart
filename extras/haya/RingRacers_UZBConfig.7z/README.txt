Please extract all the contents of this zip archive into your UZB configuration folder.

Usually located here:
C:\Program Files\Ultimate Zone Builder\Configurations

If you do not have UZB yet, please download it from here.
https://mb.srb2.org/addons/ultimate-zone-builder.6126/

Do note that this config is not finished, and therefore may have problems!